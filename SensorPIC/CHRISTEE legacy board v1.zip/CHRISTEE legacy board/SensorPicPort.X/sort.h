/* 
 * File:   sort.h
 * Author: Igor
 *
 * Created on March 21, 2014, 6:26 PM
 */

#ifndef SORT_H
#define	SORT_H

void insertionSort( unsigned int *num, int numLength);

#endif	/* SORT_H */

